package com.campus.attendance.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.attendance.entity.ClassInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ClassInfoDao extends BaseMapper<ClassInfo> {

    @Select("SELECT * FROM class_info WHERE teacher_id = #{teacherId}")
    List<ClassInfo> selectByTeacherId(@Param("teacherId") Long teacherId);
}
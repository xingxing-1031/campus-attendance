package com.campus.attendance.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.attendance.entity.AttendanceTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AttendanceTaskDao extends BaseMapper<AttendanceTask> {

    @Select("SELECT * FROM attendance_task WHERE class_id = #{classId}")
    List<AttendanceTask> selectByClassId(@Param("classId") Long classId);

    @Select("SELECT * FROM attendance_task WHERE teacher_id = #{teacherId}")
    List<AttendanceTask> selectByTeacherId(@Param("teacherId") Long teacherId);

    @Select("SELECT * FROM attendance_task WHERE status = 1 AND end_time > NOW()")
    List<AttendanceTask> selectActiveTasks();
}
package com.campus.attendance;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan("com.campus.attendance.dao")
@EnableScheduling
public class CampusAttendanceApplication {
    public static void main(String[] args) {
        SpringApplication.run(CampusAttendanceApplication.class, args);
    }
}
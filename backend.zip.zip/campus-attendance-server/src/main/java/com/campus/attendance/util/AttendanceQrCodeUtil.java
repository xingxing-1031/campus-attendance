package com.campus.attendance.util;

import cn.hutool.core.codec.Base64;
import cn.hutool.extra.qrcode.QrConfig;

public class AttendanceQrCodeUtil {

    public static String generateQrCodeBase64(String content, int width, int height) {
        try {
            QrConfig config = QrConfig.create().setWidth(width).setHeight(height);
            byte[] bytes = cn.hutool.extra.qrcode.QrCodeUtil.generatePng(content, config);
            return Base64.encode(bytes);
        } catch (Exception e) {
            throw new RuntimeException("二维码生成失败: " + e.getMessage(), e);
        }
    }

    public static String generateCheckinQrContent(Long taskId, Long teacherId, Long classId) {
        return String.format("CHECKIN:%d:%d:%d:%d", taskId, teacherId, classId, System.currentTimeMillis());
    }
}

package com.campus.attendance.controller;

import com.campus.attendance.dto.CheckinRequest;
import com.campus.attendance.dto.LeaveApplyRequest;
import com.campus.attendance.dto.Result;
import com.campus.attendance.entity.AttendanceRecord;
import com.campus.attendance.entity.LeaveApplication;
import com.campus.attendance.entity.User;
import com.campus.attendance.service.AttendanceService;
import com.campus.attendance.service.LeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/student")
public class StudentController {

    @Autowired
    private AttendanceService attendanceService;

    @Autowired
    private LeaveService leaveService;

    /**
     * 获取进行中的考勤任务列表
     */
    @GetMapping("/active-tasks")
    public Result<List<Map<String, Object>>> getActiveTasks(
            @RequestAttribute("userId") Long userId,
            @RequestAttribute("role") Integer role,
            @RequestParam(required = false) Long classId) {
        try {
            List<Map<String, Object>> tasks = attendanceService.getActiveTasks(classId, userId);
            return Result.success(tasks);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 打卡签到
     */
    @PostMapping("/checkin")
    public Result<Map<String, Object>> checkin(
            @RequestAttribute("userId") Long userId,
            @RequestBody CheckinRequest request) {
        try {
            Map<String, Object> result = attendanceService.checkin(userId, request);
            return Result.success(result);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 查看个人考勤记录
     */
    @GetMapping("/records")
    public Result<List<AttendanceRecord>> getRecords(@RequestAttribute("userId") Long userId) {
        try {
            List<AttendanceRecord> records = attendanceService.getStudentRecords(userId);
            return Result.success(records);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 提交请假申请
     */
    @PostMapping("/leave/apply")
    public Result<LeaveApplication> applyLeave(
            @RequestAttribute("userId") Long userId,
            @RequestParam Long classId,
            @RequestBody LeaveApplyRequest request) {
        try {
            LeaveApplication application = leaveService.applyLeave(userId, classId, request);
            return Result.success(application);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 查看个人请假申请记录
     */
    @GetMapping("/leave/list")
    public Result<List<LeaveApplication>> getLeaveList(@RequestAttribute("userId") Long userId) {
        try {
            List<LeaveApplication> leaves = leaveService.getStudentLeaves(userId);
            return Result.success(leaves);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }
}
package com.campus.attendance.dto;

import java.math.BigDecimal;

public class TaskCreateRequest {
    private Long classId;
    private String title;
    private Integer checkType;
    private String locationName;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Integer locationRange;
    private Integer needFace;
    private String startTime;
    private String endTime;

    public Long getClassId() {
        return classId;
    }

    public void setClassId(Long classId) {
        this.classId = classId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getCheckType() {
        return checkType;
    }

    public void setCheckType(Integer checkType) {
        this.checkType = checkType;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public Integer getLocationRange() {
        return locationRange;
    }

    public void setLocationRange(Integer locationRange) {
        this.locationRange = locationRange;
    }

    public Integer getNeedFace() {
        return needFace;
    }

    public void setNeedFace(Integer needFace) {
        this.needFace = needFace;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
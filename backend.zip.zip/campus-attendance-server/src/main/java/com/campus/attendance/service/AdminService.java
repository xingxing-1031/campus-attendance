package com.campus.attendance.service;

import com.campus.attendance.dao.*;
import com.campus.attendance.dto.AttendanceStatDTO;
import com.campus.attendance.entity.*;
import com.campus.attendance.util.PasswordUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class AdminService {

    @Autowired
    private UserDao userDao;

    @Autowired
    private ClassInfoDao classInfoDao;

    @Autowired
    private AttendanceTaskDao taskDao;

    @Autowired
    private AttendanceRecordDao recordDao;

    @Autowired
    private LeaveApplicationDao leaveDao;

    public List<User> getAllUsers() {
        return userDao.selectList(null);
    }

    public List<User> getUsersByRole(Integer role) {
        return userDao.selectByRole(role);
    }

    @Transactional
    public User addUser(User user) {
        User exist = userDao.selectByUserNo(user.getUserNo());
        if (exist != null) {
            throw new RuntimeException("学号/工号已存在");
        }
        user.setPassword(PasswordUtil.encode(user.getPassword()));
        user.setStatus(1);
        userDao.insert(user);
        return user;
    }

    @Transactional
    public void updateUser(User user) {
        User exist = userDao.selectById(user.getId());
        if (exist == null) {
            throw new RuntimeException("用户不存在");
        }
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            user.setPassword(PasswordUtil.encode(user.getPassword()));
        } else {
            user.setPassword(exist.getPassword());
        }
        user.setUserNo(exist.getUserNo());
        userDao.updateById(user);
    }

    @Transactional
    public void toggleUserStatus(Long userId) {
        User user = userDao.selectById(userId);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }
        user.setStatus(user.getStatus() == 1 ? 0 : 1);
        userDao.updateById(user);
    }

    @Transactional
    public void deleteUser(Long userId) {
        userDao.deleteById(userId);
    }

    public List<ClassInfo> getAllClasses() {
        return classInfoDao.selectList(null);
    }

    @Transactional
    public ClassInfo addClass(ClassInfo classInfo) {
        classInfoDao.insert(classInfo);
        return classInfo;
    }

    @Transactional
    public void updateClass(ClassInfo classInfo) {
        classInfoDao.updateById(classInfo);
    }

    @Transactional
    public void deleteClass(Long classId) {
        classInfoDao.deleteById(classId);
    }

    public Map<String, Object> getOverallStatistics() {
        Map<String, Object> result = new HashMap<>();

        int totalStudents = (int) userDao.selectByRole(1).stream().filter(u -> u.getStatus() == 1).count();
        int totalTeachers = (int) userDao.selectByRole(2).stream().filter(u -> u.getStatus() == 1).count();
        int totalClasses = classInfoDao.selectCount(null).intValue();

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        List<AttendanceTask> todayTasks = new ArrayList<>();
        List<AttendanceTask> allTasks = taskDao.selectList(null);
        for (AttendanceTask task : allTasks) {
            if (task.getCreateTime().toLocalDate().equals(LocalDate.now())) {
                todayTasks.add(task);
            }
        }

        int todayTotal = 0, todayCheckedIn = 0, todayAbsent = 0, todayLate = 0, todayOnLeave = 0;
        for (AttendanceTask task : todayTasks) {
            todayTotal += recordDao.countCheckedIn(task.getId()) + recordDao.countAbsent(task.getId()) + recordDao.countOnLeave(task.getId());
            todayCheckedIn += recordDao.countCheckedIn(task.getId());
            todayAbsent += recordDao.countAbsent(task.getId());
            todayOnLeave += recordDao.countOnLeave(task.getId());
        }

        result.put("totalStudents", totalStudents);
        result.put("totalTeachers", totalTeachers);
        result.put("totalClasses", totalClasses);
        result.put("todayTotal", todayTotal);
        result.put("todayCheckedIn", todayCheckedIn);
        result.put("todayAbsent", todayAbsent);
        result.put("todayLate", todayLate);
        result.put("todayOnLeave", todayOnLeave);

        return result;
    }

    public List<Map<String, Object>> getClassStatistics() {
        List<Map<String, Object>> result = new ArrayList<>();
        List<ClassInfo> classes = classInfoDao.selectList(null);

        for (ClassInfo clazz : classes) {
            Map<String, Object> stat = new HashMap<>();
            stat.put("classId", clazz.getId());
            stat.put("className", clazz.getClassName());
            stat.put("grade", clazz.getGrade());

            List<User> students = userDao.selectByClassId(clazz.getId());
            stat.put("totalStudents", students.size());

            LocalDate weekStart = LocalDate.now().with(java.time.DayOfWeek.MONDAY);
            int weekTotal = 0, weekChecked = 0;
            for (User student : students) {
                if (student.getRole() == 1) {
                    List<AttendanceRecord> records = recordDao.selectByStudentId(student.getId());
                    for (AttendanceRecord r : records) {
                        if (r.getCheckTime() != null && r.getCheckTime().toLocalDate().isAfter(weekStart.minusDays(1))) {
                            weekTotal++;
                            if (r.getStatus() == 1 || r.getStatus() == 2) {
                                weekChecked++;
                            }
                        }
                    }
                }
            }
            if (weekTotal > 0) {
                stat.put("attendanceRate", String.format("%.1f%%", weekChecked * 100.0 / weekTotal));
            } else {
                stat.put("attendanceRate", "暂无数据");
            }

            result.add(stat);
        }
        return result;
    }

    public List<Map<String, Object>> getAbnormalRecords() {
        List<Map<String, Object>> result = new ArrayList<>();
        List<AttendanceRecord> allRecords = recordDao.selectList(null);

        for (AttendanceRecord record : allRecords) {
            if (record.getFaceVerified() != null && record.getFaceVerified() == 2
                    || record.getStatus() != null && record.getStatus() == 2) {
                Map<String, Object> item = new HashMap<>();
                item.put("record", record);
                User student = userDao.selectById(record.getStudentId());
                item.put("studentName", student != null ? student.getName() : "");
                item.put("studentNo", student != null ? student.getUserNo() : "");
                AttendanceTask task = taskDao.selectById(record.getTaskId());
                item.put("taskTitle", task != null ? task.getTitle() : "");
                item.put("abnormalType", record.getFaceVerified() == 2 ? "人脸验证失败" : "迟到");
                result.add(item);
            }
        }
        return result;
    }

    public List<AttendanceStatDTO> getWeeklyTrend() {
        List<AttendanceStatDTO> result = new ArrayList<>();
        LocalDate today = LocalDate.now();

        for (int i = 6; i >= 0; i--) {
            LocalDate date = today.minusDays(i);
            String dateStr = date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

            AttendanceStatDTO dto = new AttendanceStatDTO();
            dto.setDate(dateStr);

            int total = 0, checkedIn = 0, absent = 0, late = 0, onLeave = 0;
            List<AttendanceRecord> allRecords = recordDao.selectList(null);
            for (AttendanceRecord r : allRecords) {
                if (r.getCheckTime() != null && r.getCheckTime().toLocalDate().equals(date)) {
                    total++;
                    if (r.getStatus() == 1) checkedIn++;
                    else if (r.getStatus() == 2) late++;
                    else if (r.getStatus() == 3) absent++;
                    else if (r.getStatus() == 4) onLeave++;
                }
            }

            dto.setTotal(total);
            dto.setCheckedIn(checkedIn);
            dto.setAbsent(absent);
            dto.setLate(late);
            dto.setOnLeave(onLeave);
            result.add(dto);
        }

        return result;
    }
}
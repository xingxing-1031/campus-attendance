package com.campus.attendance.service;

import cn.hutool.core.codec.Base64;
import com.campus.attendance.dao.*;
import com.campus.attendance.dto.CheckinRequest;
import com.campus.attendance.dto.TaskCreateRequest;
import com.campus.attendance.entity.*;
import com.campus.attendance.util.FaceVerifyUtil;
import com.campus.attendance.util.AttendanceQrCodeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class AttendanceService {

    @Autowired
    private AttendanceTaskDao taskDao;

    @Autowired
    private AttendanceRecordDao recordDao;

    @Autowired
    private UserDao userDao;

    @Autowired
    private ClassInfoDao classInfoDao;

    @Autowired
    private LeaveApplicationDao leaveDao;

    @Transactional
    public AttendanceTask createTask(Long teacherId, TaskCreateRequest request) {
        AttendanceTask task = new AttendanceTask();
        task.setTeacherId(teacherId);
        task.setClassId(request.getClassId());
        task.setTitle(request.getTitle());
        task.setCheckType(request.getCheckType());
        task.setLocationName(request.getLocationName());
        task.setLatitude(request.getLatitude());
        task.setLongitude(request.getLongitude());
        task.setLocationRange(request.getLocationRange() != null ? request.getLocationRange() : 500);
        task.setNeedFace(request.getNeedFace() != null ? request.getNeedFace() : 1);

        LocalDateTime startTime = parseDateTime(request.getStartTime());
        LocalDateTime endTime = parseDateTime(request.getEndTime());
        task.setStartTime(startTime);
        task.setEndTime(endTime);

        LocalDateTime now = LocalDateTime.now();
        if (now.isBefore(startTime)) {
            task.setStatus(2);
        } else if (now.isAfter(endTime)) {
            task.setStatus(0);
        } else {
            task.setStatus(1);
        }

        String qrContent = AttendanceQrCodeUtil.generateCheckinQrContent(0L, teacherId, request.getClassId());
        taskDao.insert(task);
        qrContent = AttendanceQrCodeUtil.generateCheckinQrContent(task.getId(), teacherId, request.getClassId());
        task.setQrCode(AttendanceQrCodeUtil.generateQrCodeBase64(qrContent, 300, 300));
        taskDao.updateById(task);

        return task;
    }

    private LocalDateTime parseDateTime(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) {
            return LocalDateTime.now();
        }
        String trimmed = dateStr.trim();
        try {
            if (trimmed.contains("T")) {
                return LocalDateTime.parse(trimmed.replace("T", " ").substring(0, 19), 
                    java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            }
            if (trimmed.length() == 16) {
                return LocalDateTime.parse(trimmed, java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
            }
            if (trimmed.length() == 19) {
                return LocalDateTime.parse(trimmed, java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            }
            if (trimmed.length() == 10) {
                return LocalDateTime.parse(trimmed + " 00:00:00", java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            }
        } catch (Exception e) {
            throw new RuntimeException("日期格式错误: " + dateStr);
        }
        return LocalDateTime.now();
    }

    @Transactional
    public Map<String, Object> checkin(Long studentId, CheckinRequest request) {
        Map<String, Object> result = new HashMap<>();

        AttendanceTask task = taskDao.selectById(request.getTaskId());
        if (task == null) {
            throw new RuntimeException("考勤任务不存在");
        }
        if (task.getStatus() != 1) {
            throw new RuntimeException("考勤任务已结束或未开始");
        }

        LocalDateTime now = LocalDateTime.now();
        if (now.isBefore(task.getStartTime())) {
            throw new RuntimeException("考勤尚未开始");
        }
        if (now.isAfter(task.getEndTime())) {
            throw new RuntimeException("考勤已结束");
        }

        List<AttendanceRecord> existingRecords = recordDao.selectByTaskId(request.getTaskId());
        boolean alreadyChecked = existingRecords.stream()
                .anyMatch(r -> r.getStudentId().equals(studentId));
        if (alreadyChecked) {
            throw new RuntimeException("您已经打过卡了");
        }

        List<LeaveApplication> leaves = leaveDao.selectByStudentId(studentId);
        boolean onLeave = leaves.stream()
                .anyMatch(l -> l.getTaskId() != null && l.getTaskId().equals(request.getTaskId()) && l.getStatus() == 1);
        if (onLeave) {
            throw new RuntimeException("您已请假，无需打卡");
        }

        User student = userDao.selectById(studentId);
        ClassInfo classInfo = classInfoDao.selectById(task.getClassId());

        boolean facePassed = true;
        double faceScore = 0;
        if (task.getNeedFace() == 1) {
            if (request.getFaceImageBase64() == null || request.getFaceImageBase64().isEmpty()) {
                throw new RuntimeException("本次考勤需要人脸验证，请上传人脸照片");
            }
            if (!FaceVerifyUtil.livenessDetect(request.getFaceImageBase64())) {
                result.put("success", false);
                result.put("message", "活体检测未通过，请确保是本人实时拍摄");
                result.put("faceVerified", 2);
                return result;
            }
            String referenceImage = "";
            faceScore = FaceVerifyUtil.compareFace(request.getFaceImageBase64(), referenceImage);
            if (faceScore < 80.0) {
                result.put("success", false);
                result.put("message", "人脸验证未通过，相似度: " + String.format("%.1f", faceScore) + "%，请重试");
                result.put("faceVerified", 2);
                result.put("faceScore", faceScore);
                return result;
            }
            facePassed = true;
        }

        if (request.getCheckType() == 1 && task.getLatitude() != null && task.getLongitude() != null) {
            double distance = calculateDistance(
                    request.getLatitude().doubleValue(), request.getLongitude().doubleValue(),
                    task.getLatitude().doubleValue(), task.getLongitude().doubleValue()
            );
            if (distance > task.getLocationRange()) {
                throw new RuntimeException("您不在签到范围内，距离签到点约" + String.format("%.0f", distance) + "米");
            }
        }

        Integer recordStatus = 1;
        if (now.isAfter(task.getStartTime().plusMinutes(10))) {
            recordStatus = 2;
        }

        AttendanceRecord record = new AttendanceRecord();
        record.setTaskId(request.getTaskId());
        record.setStudentId(studentId);
        record.setClassId(task.getClassId());
        record.setCheckTime(now);
        record.setCheckType(request.getCheckType());
        record.setLatitude(request.getLatitude());
        record.setLongitude(request.getLongitude());
        record.setFaceVerified(facePassed ? 1 : 2);
        record.setFaceScore(BigDecimal.valueOf(faceScore));
        record.setStatus(recordStatus);
        recordDao.insert(record);

        result.put("success", true);
        result.put("message", "打卡成功");
        result.put("faceVerified", facePassed ? 1 : 2);
        result.put("faceScore", faceScore);
        result.put("status", recordStatus == 1 ? "正常" : "迟到");
        return result;
    }

    private double calculateDistance(double lat1, double lng1, double lat2, double lng2) {
        double R = 6371000;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    public List<Map<String, Object>> getActiveTasks(Long classId, Long studentId) {
        List<AttendanceTask> tasks = taskDao.selectActiveTasks();
        List<Map<String, Object>> result = new ArrayList<>();

        for (AttendanceTask task : tasks) {
            if (task.getClassId().equals(classId) || classId == null) {
                Map<String, Object> map = new HashMap<>();
                map.put("taskId", task.getId());
                map.put("title", task.getTitle());
                map.put("checkType", task.getCheckType());
                map.put("locationName", task.getLocationName());
                map.put("needFace", task.getNeedFace());
                map.put("startTime", task.getStartTime());
                map.put("endTime", task.getEndTime());
                map.put("qrCode", task.getQrCode());

                List<AttendanceRecord> records = recordDao.selectByTaskId(task.getId());
                boolean checked = records.stream().anyMatch(r -> r.getStudentId().equals(studentId));
                map.put("checked", checked);

                ClassInfo classInfo = classInfoDao.selectById(task.getClassId());
                map.put("className", classInfo != null ? classInfo.getClassName() : "");
                result.add(map);
            }
        }
        return result;
    }

    public List<AttendanceRecord> getStudentRecords(Long studentId) {
        return recordDao.selectByStudentId(studentId);
    }

    public List<Map<String, Object>> getTeacherTasks(Long teacherId) {
        List<AttendanceTask> tasks = taskDao.selectByTeacherId(teacherId);
        List<Map<String, Object>> result = new ArrayList<>();
        for (AttendanceTask task : tasks) {
            Map<String, Object> map = new HashMap<>();
            map.put("task", task);
            int checkedIn = recordDao.countCheckedIn(task.getId());
            int absent = recordDao.countAbsent(task.getId());
            int onLeave = recordDao.countOnLeave(task.getId());
            ClassInfo classInfo = classInfoDao.selectById(task.getClassId());
            int totalStudents = (int) userDao.selectByClassId(task.getClassId()).stream()
                    .filter(u -> u.getRole() == 1).count();
            map.put("checkedIn", checkedIn);
            map.put("absent", absent);
            map.put("onLeave", onLeave);
            map.put("totalStudents", totalStudents);
            map.put("className", classInfo != null ? classInfo.getClassName() : "");
            result.add(map);
        }
        return result;
    }

    public Map<String, Object> getTaskDetail(Long taskId) {
        AttendanceTask task = taskDao.selectById(taskId);
        if (task == null) {
            throw new RuntimeException("考勤任务不存在");
        }
        List<AttendanceRecord> records = recordDao.selectByTaskId(taskId);
        List<User> students = userDao.selectByClassId(task.getClassId());
        students.removeIf(u -> u.getRole() != 1);

        List<Map<String, Object>> recordList = new ArrayList<>();
        for (User student : students) {
            Map<String, Object> item = new HashMap<>();
            item.put("studentId", student.getId());
            item.put("studentName", student.getName());
            item.put("studentNo", student.getUserNo());

            Optional<AttendanceRecord> record = records.stream()
                    .filter(r -> r.getStudentId().equals(student.getId()))
                    .findFirst();

            if (record.isPresent()) {
                item.put("status", record.get().getStatus());
                item.put("statusText", getStatusText(record.get().getStatus()));
                item.put("checkTime", record.get().getCheckTime());
                item.put("checkType", record.get().getCheckType());
                item.put("faceVerified", record.get().getFaceVerified());
            } else {
                List<LeaveApplication> leaves = leaveDao.selectByStudentId(student.getId());
                boolean onLeave = leaves.stream()
                        .anyMatch(l -> l.getTaskId() != null && l.getTaskId().equals(taskId) && l.getStatus() == 1);
                if (onLeave) {
                    item.put("status", 4);
                    item.put("statusText", "请假");
                } else {
                    item.put("status", 3);
                    item.put("statusText", "缺勤");
                }
            }
            recordList.add(item);
        }

        Map<String, Object> result = new HashMap<>();
        result.put("task", task);
        result.put("records", recordList);
        result.put("checkedIn", recordDao.countCheckedIn(taskId));
        result.put("absent", recordDao.countAbsent(taskId));
        result.put("onLeave", recordDao.countOnLeave(taskId));
        return result;
    }

    private String getStatusText(Integer status) {
        switch (status) {
            case 1: return "正常";
            case 2: return "迟到";
            case 3: return "缺勤";
            case 4: return "请假";
            default: return "未知";
        }
    }

    public void toggleFaceVerify(Long taskId, Integer needFace) {
        AttendanceTask task = taskDao.selectById(taskId);
        if (task == null) {
            throw new RuntimeException("考勤任务不存在");
        }
        task.setNeedFace(needFace);
        taskDao.updateById(task);
    }

    @Transactional
    public void deleteTask(Long taskId) {
        AttendanceTask task = taskDao.selectById(taskId);
        if (task == null) {
            throw new RuntimeException("考勤任务不存在");
        }
        recordDao.deleteByTaskId(taskId);
        leaveDao.deleteByTaskId(taskId);
        taskDao.deleteById(taskId);
    }

    @Transactional
    public void autoEndExpiredTasks() {
        List<AttendanceTask> activeTasks = taskDao.selectActiveTasks();
        LocalDateTime now = LocalDateTime.now();
        for (AttendanceTask task : activeTasks) {
            if (now.isAfter(task.getEndTime())) {
                task.setStatus(0);
                taskDao.updateById(task);
            }
        }
    }

    public String exportTaskData(Long taskId) {
        Map<String, Object> detail = getTaskDetail(taskId);
        AttendanceTask task = (AttendanceTask) detail.get("task");
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> records = (List<Map<String, Object>>) detail.get("records");

        StringBuilder sb = new StringBuilder();
        sb.append("考勤任务:, ").append(task.getTitle()).append("\n");
        sb.append("班级:, ").append(detail.get("className") != null ? detail.get("className") : "").append("\n");
        sb.append("时间:, ").append(task.getStartTime()).append(" ~ ").append(task.getEndTime()).append("\n");
        sb.append("\n");
        sb.append("学号,姓名,状态,打卡时间,打卡方式,人脸验证\n");

        for (Map<String, Object> r : records) {
            sb.append(r.get("studentNo")).append(",");
            sb.append(r.get("studentName")).append(",");
            sb.append(r.get("statusText")).append(",");
            sb.append(r.get("checkTime") != null ? r.get("checkTime") : "-").append(",");
            sb.append(r.get("checkType") != null ? (r.get("checkType").equals(1) ? "GPS定位" : "二维码") : "-").append(",");
            sb.append(r.get("faceVerified") != null ? (r.get("faceVerified").equals(1) ? "通过" : "未通过") : "-").append("\n");
        }

        sb.append("\n");
        sb.append("统计:, ").append("已签到: ").append(detail.get("checkedIn"));
        sb.append(", 缺勤: ").append(detail.get("absent"));
        sb.append(", 请假: ").append(detail.get("onLeave")).append("\n");

        return sb.toString();
    }
}
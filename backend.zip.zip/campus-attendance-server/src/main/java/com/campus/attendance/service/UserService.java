package com.campus.attendance.service;

import com.campus.attendance.dao.ClassInfoDao;
import com.campus.attendance.dao.UserDao;
import com.campus.attendance.dto.LoginRequest;
import com.campus.attendance.dto.LoginResponse;
import com.campus.attendance.dto.PasswordResetRequest;
import com.campus.attendance.entity.ClassInfo;
import com.campus.attendance.entity.User;
import com.campus.attendance.util.JwtUtil;
import com.campus.attendance.util.PasswordUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    @Autowired
    private ClassInfoDao classInfoDao;

    public LoginResponse login(LoginRequest request) {
        User user = userDao.selectByUserNo(request.getUserNo());
        if (user == null) {
            throw new RuntimeException("账号不存在");
        }
        if (user.getStatus() == 0) {
            throw new RuntimeException("账号已被禁用，请联系管理员");
        }
        if (!PasswordUtil.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("密码错误");
        }
        String token = JwtUtil.generateToken(user.getId(), user.getUserNo(), user.getRole());
        LoginResponse response = new LoginResponse();
        response.setToken(token);
        response.setUserId(user.getId());
        response.setUserNo(user.getUserNo());
        response.setName(user.getName());
        response.setRole(user.getRole());
        response.setClassId(user.getClassId());
        if (user.getClassId() != null) {
            ClassInfo classInfo = classInfoDao.selectById(user.getClassId());
            if (classInfo != null) {
                response.setClassName(classInfo.getClassName());
            }
        }
        return response;
    }

    public void resetPassword(PasswordResetRequest request) {
        User user = userDao.selectByUserNo(request.getUserNo());
        if (user == null) {
            throw new RuntimeException("账号不存在");
        }
        if (!PasswordUtil.matches(request.getOldPassword(), user.getPassword())) {
            throw new RuntimeException("原密码错误");
        }
        user.setPassword(PasswordUtil.encode(request.getNewPassword()));
        userDao.updateById(user);
    }

    public User getUserById(Long userId) {
        return userDao.selectById(userId);
    }
}
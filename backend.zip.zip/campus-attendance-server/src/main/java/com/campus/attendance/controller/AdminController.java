package com.campus.attendance.controller;

import com.campus.attendance.dto.AttendanceStatDTO;
import com.campus.attendance.dto.Result;
import com.campus.attendance.entity.ClassInfo;
import com.campus.attendance.entity.User;
import com.campus.attendance.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // ========== 用户管理 ==========

    /**
     * 获取所有用户
     */
    @GetMapping("/users")
    public Result<List<User>> getAllUsers() {
        try {
            return Result.success(adminService.getAllUsers());
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 按角色获取用户
     */
    @GetMapping("/users/role/{role}")
    public Result<List<User>> getUsersByRole(@PathVariable Integer role) {
        try {
            return Result.success(adminService.getUsersByRole(role));
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 添加用户
     */
    @PostMapping("/users")
    public Result<User> addUser(@RequestBody User user) {
        try {
            return Result.success(adminService.addUser(user));
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 更新用户
     */
    @PutMapping("/users")
    public Result<Void> updateUser(@RequestBody User user) {
        try {
            adminService.updateUser(user);
            return Result.success();
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 切换用户启用/禁用状态
     */
    @PutMapping("/users/{userId}/toggle-status")
    public Result<Void> toggleUserStatus(@PathVariable Long userId) {
        try {
            adminService.toggleUserStatus(userId);
            return Result.success();
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 删除用户
     */
    @DeleteMapping("/users/{userId}")
    public Result<Void> deleteUser(@PathVariable Long userId) {
        try {
            adminService.deleteUser(userId);
            return Result.success();
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    // ========== 班级管理 ==========

    /**
     * 获取所有班级
     */
    @GetMapping("/classes")
    public Result<List<ClassInfo>> getAllClasses() {
        try {
            return Result.success(adminService.getAllClasses());
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 添加班级
     */
    @PostMapping("/classes")
    public Result<ClassInfo> addClass(@RequestBody ClassInfo classInfo) {
        try {
            return Result.success(adminService.addClass(classInfo));
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 更新班级
     */
    @PutMapping("/classes")
    public Result<Void> updateClass(@RequestBody ClassInfo classInfo) {
        try {
            adminService.updateClass(classInfo);
            return Result.success();
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 删除班级
     */
    @DeleteMapping("/classes/{classId}")
    public Result<Void> deleteClass(@PathVariable Long classId) {
        try {
            adminService.deleteClass(classId);
            return Result.success();
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    // ========== 统计 ==========

    /**
     * 获取全校考勤汇总统计
     */
    @GetMapping("/statistics/overall")
    public Result<Map<String, Object>> getOverallStatistics() {
        try {
            return Result.success(adminService.getOverallStatistics());
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 按班级统计考勤
     */
    @GetMapping("/statistics/classes")
    public Result<List<Map<String, Object>>> getClassStatistics() {
        try {
            return Result.success(adminService.getClassStatistics());
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 获异常考勤记录
     */
    @GetMapping("/statistics/abnormal")
    public Result<List<Map<String, Object>>> getAbnormalRecords() {
        try {
            return Result.success(adminService.getAbnormalRecords());
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 获取近7天考勤趋势
     */
    @GetMapping("/statistics/weekly-trend")
    public Result<List<AttendanceStatDTO>> getWeeklyTrend() {
        try {
            return Result.success(adminService.getWeeklyTrend());
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }
}
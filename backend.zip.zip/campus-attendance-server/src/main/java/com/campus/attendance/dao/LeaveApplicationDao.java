package com.campus.attendance.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.attendance.entity.LeaveApplication;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface LeaveApplicationDao extends BaseMapper<LeaveApplication> {

    @Select("SELECT * FROM leave_application WHERE student_id = #{studentId}")
    List<LeaveApplication> selectByStudentId(@Param("studentId") Long studentId);

    @Select("SELECT * FROM leave_application WHERE class_id = #{classId}")
    List<LeaveApplication> selectByClassId(@Param("classId") Long classId);

    @Select("SELECT * FROM leave_application WHERE class_id = #{classId} AND status = 0 ORDER BY create_time DESC")
    List<LeaveApplication> selectPendingByClassId(@Param("classId") Long classId);

    @Delete("DELETE FROM leave_application WHERE task_id = #{taskId}")
    int deleteByTaskId(@Param("taskId") Long taskId);
}
package com.campus.attendance.dto;

public class AttendanceStatDTO {
    private String date;
    private Integer total;
    private Integer checkedIn;
    private Integer absent;
    private Integer late;
    private Integer onLeave;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getCheckedIn() {
        return checkedIn;
    }

    public void setCheckedIn(Integer checkedIn) {
        this.checkedIn = checkedIn;
    }

    public Integer getAbsent() {
        return absent;
    }

    public void setAbsent(Integer absent) {
        this.absent = absent;
    }

    public Integer getLate() {
        return late;
    }

    public void setLate(Integer late) {
        this.late = late;
    }

    public Integer getOnLeave() {
        return onLeave;
    }

    public void setOnLeave(Integer onLeave) {
        this.onLeave = onLeave;
    }
}
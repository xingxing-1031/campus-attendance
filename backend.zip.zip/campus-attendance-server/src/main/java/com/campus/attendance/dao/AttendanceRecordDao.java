package com.campus.attendance.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.attendance.entity.AttendanceRecord;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AttendanceRecordDao extends BaseMapper<AttendanceRecord> {

    @Select("SELECT * FROM attendance_record WHERE task_id = #{taskId}")
    List<AttendanceRecord> selectByTaskId(@Param("taskId") Long taskId);

    @Select("SELECT * FROM attendance_record WHERE student_id = #{studentId}")
    List<AttendanceRecord> selectByStudentId(@Param("studentId") Long studentId);

    @Select("SELECT * FROM attendance_record WHERE class_id = #{classId} AND DATE(create_time) = #{date}")
    List<AttendanceRecord> selectByClassIdAndDate(@Param("classId") Long classId, @Param("date") String date);

    @Select("SELECT COUNT(*) FROM attendance_record WHERE task_id = #{taskId} AND status = 1")
    int countCheckedIn(@Param("taskId") Long taskId);

    @Select("SELECT COUNT(*) FROM attendance_record WHERE task_id = #{taskId} AND status = 3")
    int countAbsent(@Param("taskId") Long taskId);

    @Select("SELECT COUNT(*) FROM attendance_record WHERE task_id = #{taskId} AND status = 4")
    int countOnLeave(@Param("taskId") Long taskId);

    @Delete("DELETE FROM attendance_record WHERE task_id = #{taskId}")
    int deleteByTaskId(@Param("taskId") Long taskId);
}
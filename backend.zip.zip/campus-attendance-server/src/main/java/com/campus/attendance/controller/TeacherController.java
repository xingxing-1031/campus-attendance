package com.campus.attendance.controller;

import com.campus.attendance.dto.ApproveRequest;
import com.campus.attendance.dto.Result;
import com.campus.attendance.dto.TaskCreateRequest;
import com.campus.attendance.entity.AttendanceTask;
import com.campus.attendance.entity.LeaveApplication;
import com.campus.attendance.service.AttendanceService;
import com.campus.attendance.service.LeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/teacher")
public class TeacherController {

    @Autowired
    private AttendanceService attendanceService;

    @Autowired
    private LeaveService leaveService;

    /**
     * 创建考勤任务
     */
    @PostMapping("/task/create")
    public Result<AttendanceTask> createTask(
            @RequestAttribute("userId") Long userId,
            @RequestBody TaskCreateRequest request) {
        try {
            AttendanceTask task = attendanceService.createTask(userId, request);
            return Result.success(task);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 获取教师创建的考勤任务列表
     */
    @GetMapping("/task/list")
    public Result<List<Map<String, Object>>> getTasks(@RequestAttribute("userId") Long userId) {
        try {
            List<Map<String, Object>> tasks = attendanceService.getTeacherTasks(userId);
            return Result.success(tasks);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 查看考勤任务详情（班级签到情况）
     */
    @GetMapping("/task/detail/{taskId}")
    public Result<Map<String, Object>> getTaskDetail(@PathVariable Long taskId) {
        try {
            Map<String, Object> detail = attendanceService.getTaskDetail(taskId);
            return Result.success(detail);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 切换人脸验证开关
     */
    @PutMapping("/task/{taskId}/face-verify/{needFace}")
    public Result<Void> toggleFaceVerify(
            @PathVariable Long taskId,
            @PathVariable Integer needFace) {
        try {
            attendanceService.toggleFaceVerify(taskId, needFace);
            return Result.success();
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 导出考勤数据
     */
    @GetMapping("/task/export/{taskId}")
    public Result<String> exportData(@PathVariable Long taskId) {
        try {
            String csvData = attendanceService.exportTaskData(taskId);
            return Result.success(csvData);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 删除考勤任务
     */
    @DeleteMapping("/task/{taskId}")
    public Result<Void> deleteTask(@PathVariable Long taskId) {
        try {
            attendanceService.deleteTask(taskId);
            return Result.success();
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 获取待审批请假申请
     */
    @GetMapping("/leave/pending/{classId}")
    public Result<List<LeaveApplication>> getPendingLeaves(@PathVariable Long classId) {
        try {
            List<LeaveApplication> leaves = leaveService.getPendingLeavesByClassId(classId);
            return Result.success(leaves);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 获取班级所有请假申请
     */
    @GetMapping("/leave/list/{classId}")
    public Result<List<LeaveApplication>> getClassLeaves(@PathVariable Long classId) {
        try {
            List<LeaveApplication> leaves = leaveService.getLeavesByClassId(classId);
            return Result.success(leaves);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    /**
     * 审批请假申请
     */
    @PostMapping("/leave/approve")
    public Result<Void> approveLeave(
            @RequestAttribute("userId") Long userId,
            @RequestBody ApproveRequest request) {
        try {
            leaveService.approveLeave(userId, request);
            return Result.success();
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }
}
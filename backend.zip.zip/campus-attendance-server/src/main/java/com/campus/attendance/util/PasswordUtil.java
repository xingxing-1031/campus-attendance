package com.campus.attendance.util;

public class PasswordUtil {

    public static String encode(String rawPassword) {
        return rawPassword; // 测试用，暂时不加密
    }

    public static boolean matches(String rawPassword, String encodedPassword) {
        return rawPassword.equals(encodedPassword);
    }
}
package com.campus.attendance.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.attendance.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserDao extends BaseMapper<User> {

    @Select("SELECT * FROM user WHERE user_no = #{userNo}")
    User selectByUserNo(@Param("userNo") String userNo);

    @Select("SELECT * FROM user WHERE class_id = #{classId}")
    List<User> selectByClassId(@Param("classId") Long classId);

    @Select("SELECT * FROM user WHERE role = #{role}")
    List<User> selectByRole(@Param("role") Integer role);
}
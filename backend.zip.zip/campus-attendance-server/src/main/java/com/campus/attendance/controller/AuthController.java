package com.campus.attendance.controller;

import com.campus.attendance.dto.LoginRequest;
import com.campus.attendance.dto.LoginResponse;
import com.campus.attendance.dto.PasswordResetRequest;
import com.campus.attendance.dto.Result;
import com.campus.attendance.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public Result<LoginResponse> login(@RequestBody LoginRequest request) {
        try {
            LoginResponse response = userService.login(request);
            return Result.success(response);
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/reset-password")
    public Result<Void> resetPassword(@RequestBody PasswordResetRequest request) {
        try {
            userService.resetPassword(request);
            return Result.success();
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/user-info")
    public Result<?> getUserInfo(@RequestAttribute("userId") Long userId) {
        try {
            return Result.success(userService.getUserById(userId));
        } catch (RuntimeException e) {
            return Result.error(e.getMessage());
        }
    }
}
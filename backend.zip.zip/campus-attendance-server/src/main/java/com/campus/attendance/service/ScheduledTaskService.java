package com.campus.attendance.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ScheduledTaskService {

    @Autowired
    private AttendanceService attendanceService;

    @Scheduled(fixedRate = 60000)
    public void autoEndTasks() {
        attendanceService.autoEndExpiredTasks();
    }
}
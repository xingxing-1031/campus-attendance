package com.campus.attendance.service;

import com.campus.attendance.dao.AttendanceRecordDao;
import com.campus.attendance.dao.AttendanceTaskDao;
import com.campus.attendance.dao.LeaveApplicationDao;
import com.campus.attendance.dto.ApproveRequest;
import com.campus.attendance.dto.LeaveApplyRequest;
import com.campus.attendance.entity.AttendanceRecord;
import com.campus.attendance.entity.LeaveApplication;
import com.campus.attendance.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class LeaveService {

    @Autowired
    private LeaveApplicationDao leaveDao;

    @Autowired
    private AttendanceRecordDao recordDao;

    @Autowired
    private AttendanceTaskDao taskDao;

    @Transactional
    public LeaveApplication applyLeave(Long studentId, Long classId, LeaveApplyRequest request) {
        LeaveApplication application = new LeaveApplication();
        application.setStudentId(studentId);
        application.setClassId(classId);
        application.setTaskId(request.getTaskId());
        application.setLeaveType(request.getLeaveType());
        application.setReason(request.getReason());
        application.setStartTime(request.getStartTime());
        application.setEndTime(request.getEndTime());
        application.setStatus(0);
        leaveDao.insert(application);

        if (request.getTaskId() != null) {
            List<AttendanceRecord> records = recordDao.selectByTaskId(request.getTaskId());
            for (AttendanceRecord record : records) {
                if (record.getStudentId().equals(studentId)) {
                    record.setStatus(4);
                    record.setRemark("已请假");
                    recordDao.updateById(record);
                }
            }
        }

        return application;
    }

    public List<LeaveApplication> getStudentLeaves(Long studentId) {
        return leaveDao.selectByStudentId(studentId);
    }

    public List<LeaveApplication> getPendingLeavesByClassId(Long classId) {
        return leaveDao.selectPendingByClassId(classId);
    }

    public List<LeaveApplication> getLeavesByClassId(Long classId) {
        return leaveDao.selectByClassId(classId);
    }

    @Transactional
    public void approveLeave(Long teacherId, ApproveRequest request) {
        LeaveApplication application = leaveDao.selectById(request.getApplicationId());
        if (application == null) {
            throw new RuntimeException("请假申请不存在");
        }
        if (application.getStatus() != 0) {
            throw new RuntimeException("该申请已处理");
        }

        application.setStatus(request.getStatus());
        application.setApproveTeacherId(teacherId);
        application.setApproveTime(LocalDateTime.now());
        application.setApproveRemark(request.getRemark());
        leaveDao.updateById(application);

        if (request.getStatus() == 1 && application.getTaskId() != null) {
            List<AttendanceRecord> records = recordDao.selectByTaskId(application.getTaskId());
            for (AttendanceRecord record : records) {
                if (record.getStudentId().equals(application.getStudentId())) {
                    record.setStatus(4);
                    record.setRemark("已请假");
                    recordDao.updateById(record);
                }
            }
        }
    }
}
-- =============================================
-- 校园智能考勤系统 - 数据库初始化脚本
-- 数据库: MySQL 8.0+
-- =============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+08:00";

DROP DATABASE IF EXISTS campus_attendance;
CREATE DATABASE campus_attendance DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE campus_attendance;

-- 用户表
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `user_no` VARCHAR(32) NOT NULL COMMENT '学号/工号',
    `password` VARCHAR(128) NOT NULL COMMENT '密码(BCrypt加密)',
    `name` VARCHAR(64) NOT NULL COMMENT '真实姓名',
    `role` TINYINT NOT NULL COMMENT '角色: 1-学生 2-教师 3-管理员',
    `phone` VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    `email` VARCHAR(64) DEFAULT NULL COMMENT '邮箱',
    `class_id` BIGINT DEFAULT NULL COMMENT '所属班级ID',
    `avatar_url` VARCHAR(256) DEFAULT NULL COMMENT '头像URL',
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态: 0-禁用 1-正常',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_no` (`user_no`),
    KEY `idx_role` (`role`),
    KEY `idx_class_id` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 班级/课程表
DROP TABLE IF EXISTS `class_info`;
CREATE TABLE `class_info` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `class_name` VARCHAR(128) NOT NULL COMMENT '班级名称',
    `grade` VARCHAR(32) DEFAULT NULL COMMENT '年级',
    `major` VARCHAR(128) DEFAULT NULL COMMENT '专业',
    `teacher_id` BIGINT DEFAULT NULL COMMENT '班主任/负责教师ID',
    `semester` VARCHAR(32) DEFAULT NULL COMMENT '学期',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_teacher_id` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='班级信息表';

-- 考勤任务表
DROP TABLE IF EXISTS `attendance_task`;
CREATE TABLE `attendance_task` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `teacher_id` BIGINT NOT NULL COMMENT '发起教师ID',
    `class_id` BIGINT NOT NULL COMMENT '班级ID',
    `title` VARCHAR(256) NOT NULL COMMENT '考勤任务标题',
    `check_type` TINYINT NOT NULL COMMENT '打卡方式: 1-GPS定位 2-二维码扫码 3-两者均可',
    `location_name` VARCHAR(256) DEFAULT NULL COMMENT '打卡地点名称',
    `latitude` DECIMAL(10, 7) DEFAULT NULL COMMENT '纬度',
    `longitude` DECIMAL(10, 7) DEFAULT NULL COMMENT '经度',
    `location_range` INT DEFAULT 500 COMMENT '定位有效范围(米)',
    `qr_code` MEDIUMTEXT DEFAULT NULL COMMENT '签到二维码内容',
    `need_face` TINYINT NOT NULL DEFAULT 1 COMMENT '是否启用人脸验证: 0-关闭 1-开启',
    `start_time` DATETIME NOT NULL COMMENT '开始时间',
    `end_time` DATETIME NOT NULL COMMENT '结束时间',
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态: 0-已结束 1-进行中 2-未开始',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_teacher_id` (`teacher_id`),
    KEY `idx_class_id` (`class_id`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='考勤任务表';

-- 考勤记录表
DROP TABLE IF EXISTS `attendance_record`;
CREATE TABLE `attendance_record` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `task_id` BIGINT NOT NULL COMMENT '考勤任务ID',
    `student_id` BIGINT NOT NULL COMMENT '学生ID',
    `class_id` BIGINT NOT NULL COMMENT '班级ID',
    `check_time` DATETIME NOT NULL COMMENT '打卡时间',
    `check_type` TINYINT NOT NULL COMMENT '打卡方式: 1-GPS定位 2-二维码扫码',
    `latitude` DECIMAL(10, 7) DEFAULT NULL COMMENT '打卡纬度',
    `longitude` DECIMAL(10, 7) DEFAULT NULL COMMENT '打卡经度',
    `face_verified` TINYINT DEFAULT 0 COMMENT '人脸验证: 0-未验证 1-验证通过 2-验证失败',
    `face_score` DECIMAL(5, 2) DEFAULT NULL COMMENT '人脸比对分数',
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态: 0-无效 1-正常 2-迟到 3-缺勤 4-请假',
    `remark` VARCHAR(512) DEFAULT NULL COMMENT '备注',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_task_id` (`task_id`),
    KEY `idx_student_id` (`student_id`),
    KEY `idx_class_id` (`class_id`),
    KEY `idx_check_time` (`check_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='考勤记录表';

-- 请假申请表
DROP TABLE IF EXISTS `leave_application`;
CREATE TABLE `leave_application` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `student_id` BIGINT NOT NULL COMMENT '学生ID',
    `class_id` BIGINT NOT NULL COMMENT '班级ID',
    `task_id` BIGINT DEFAULT NULL COMMENT '关联考勤任务ID',
    `leave_type` TINYINT NOT NULL COMMENT '请假类型: 1-病假 2-事假 3-其他',
    `reason` VARCHAR(1024) NOT NULL COMMENT '请假原因',
    `start_time` DATETIME NOT NULL COMMENT '请假开始时间',
    `end_time` DATETIME NOT NULL COMMENT '请假结束时间',
    `attachment_url` VARCHAR(512) DEFAULT NULL COMMENT '附件URL(如病假证明)',
    `status` TINYINT NOT NULL DEFAULT 0 COMMENT '状态: 0-待审批 1-已批准 2-已驳回',
    `approve_teacher_id` BIGINT DEFAULT NULL COMMENT '审批教师ID',
    `approve_time` DATETIME DEFAULT NULL COMMENT '审批时间',
    `approve_remark` VARCHAR(512) DEFAULT NULL COMMENT '审批备注',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_student_id` (`student_id`),
    KEY `idx_class_id` (`class_id`),
    KEY `idx_task_id` (`task_id`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='请假申请表';

-- 插入默认管理员账号 (密码: admin123)
INSERT INTO `user` (`user_no`, `password`, `name`, `role`, `status`) VALUES
('admin001', 'admin123', '系统管理员', 3, 1);

-- 插入测试教师账号 (密码: teacher123)
INSERT INTO `user` (`user_no`, `password`, `name`, `role`, `status`) VALUES
('t001', 'teacher123', '张老师', 2, 1);

-- 插入测试学生账号 (密码: student123)
INSERT INTO `user` (`user_no`, `password`, `name`, `role`, `class_id`, `status`) VALUES
('s001', 'student123', '李同学', 1, 1, 1);

-- 插入测试班级
INSERT INTO `class_info` (`class_name`, `grade`, `major`, `teacher_id`, `semester`) VALUES
('计算机科学2025级1班', '2025', '计算机科学与技术', 2, '2025-2026学年第一学期');
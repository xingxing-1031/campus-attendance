Component({
  properties: {
    title: {
      type: String,
      value: ''
    },
    showBack: {
      type: Boolean,
      value: true
    },
    actionText: {
      type: String,
      value: ''
    }
  },

  methods: {
    goBack() {
      wx.navigateBack({ delta: 1 });
    },
    onAction() {
      this.triggerEvent('navbaraction');
    }
  }
});
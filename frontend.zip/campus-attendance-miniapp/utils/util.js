const formatTime = (dateStr) => {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  const year = date.getFullYear();
  const month = padZero(date.getMonth() + 1);
  const day = padZero(date.getDate());
  const hour = padZero(date.getHours());
  const minute = padZero(date.getMinutes());
  return `${year}-${month}-${day} ${hour}:${minute}`;
};

const padZero = (n) => {
  return n < 10 ? '0' + n : '' + n;
};

const getCheckTypeText = (type) => {
  switch (type) {
    case 1: return 'GPS定位';
    case 2: return '二维码扫码';
    case 3: return 'GPS/二维码';
    default: return '未知';
  }
};

const getStatusText = (status) => {
  switch (status) {
    case 0: return '已结束';
    case 1: return '进行中';
    case 2: return '未开始';
    default: return '未知';
  }
};

const getRecordStatusText = (status) => {
  switch (status) {
    case 1: return '正常';
    case 2: return '迟到';
    case 3: return '缺勤';
    case 4: return '请假';
    default: return '未知';
  }
};

const getLeaveTypeText = (type) => {
  switch (type) {
    case 1: return '病假';
    case 2: return '事假';
    case 3: return '其他';
    default: return '未知';
  }
};

const getLeaveStatusText = (status) => {
  switch (status) {
    case 0: return '待审批';
    case 1: return '已批准';
    case 2: return '已驳回';
    default: return '未知';
  }
};

const getRoleText = (role) => {
  switch (role) {
    case 1: return '学生';
    case 2: return '教师';
    case 3: return '管理员';
    default: return '未知';
  }
};

const showConfirm = (title, content) => {
  return new Promise((resolve) => {
    wx.showModal({
      title: title,
      content: content,
      success(res) {
        resolve(res.confirm);
      }
    });
  });
};

module.exports = {
  formatTime,
  padZero,
  getCheckTypeText,
  getStatusText,
  getRecordStatusText,
  getLeaveTypeText,
  getLeaveStatusText,
  getRoleText,
  showConfirm
};
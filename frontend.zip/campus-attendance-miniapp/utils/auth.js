const app = getApp();

const checkPermission = () => {
  if (!app || !app.checkLogin()) {
    return false;
  }
  return true;
};

const requestCameraPermission = () => {
  return new Promise((resolve, reject) => {
    wx.authorize({
      scope: 'scope.camera',
      success() {
        resolve(true);
      },
      fail() {
        wx.showModal({
          title: '权限申请',
          content: '人脸验证需要使用相机，请在设置中允许使用摄像头',
          success(res) {
            if (res.confirm) {
              wx.openSetting({
                success(settingRes) {
                  if (settingRes.authSetting['scope.camera']) {
                    resolve(true);
                  } else {
                    reject(new Error('需要相机权限'));
                  }
                }
              });
            } else {
              reject(new Error('需要相机权限'));
            }
          }
        });
      }
    });
  });
};

const requestLocationPermission = () => {
  return new Promise((resolve, reject) => {
    wx.authorize({
      scope: 'scope.userLocation',
      success() {
        resolve(true);
      },
      fail() {
        wx.showModal({
          title: '权限申请',
          content: 'GPS定位打卡需要获取位置信息，请在设置中允许',
          success(res) {
            if (res.confirm) {
              wx.openSetting({
                success(settingRes) {
                  if (settingRes.authSetting['scope.userLocation']) {
                    resolve(true);
                  } else {
                    reject(new Error('需要定位权限'));
                  }
                }
              });
            } else {
              reject(new Error('需要定位权限'));
            }
          }
        });
      }
    });
  });
};

const getLocation = () => {
  return new Promise((resolve, reject) => {
    wx.getLocation({
      type: 'gcj02',
      success(res) {
        resolve({
          latitude: res.latitude,
          longitude: res.longitude
        });
      },
      fail(err) {
        reject(err);
      }
    });
  });
};

const takePhoto = () => {
  return new Promise((resolve, reject) => {
    const ctx = wx.createCameraContext();
    ctx.takePhoto({
      quality: 'high',
      success(res) {
        wx.getFileSystemManager().readFile({
          filePath: res.tempImagePath,
          encoding: 'base64',
          success(fileRes) {
            resolve(fileRes.data);
          },
          fail(err) {
            reject(err);
          }
        });
      },
      fail(err) {
        reject(err);
      }
    });
  });
};

const chooseAndCompressImage = () => {
  return new Promise((resolve, reject) => {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['camera'],
      success(res) {
        wx.getFileSystemManager().readFile({
          filePath: res.tempFilePaths[0],
          encoding: 'base64',
          success(fileRes) {
            resolve(fileRes.data);
          },
          fail(err) {
            reject(err);
          }
        });
      },
      fail(err) {
        reject(err);
      }
    });
  });
};

const scanQrCode = () => {
  return new Promise((resolve, reject) => {
    wx.scanCode({
      onlyFromCamera: true,
      success(res) {
        resolve(res.result);
      },
      fail(err) {
        reject(err);
      }
    });
  });
};

module.exports = {
  checkPermission,
  requestCameraPermission,
  requestLocationPermission,
  getLocation,
  takePhoto,
  chooseAndCompressImage,
  scanQrCode
};
const app = getApp();

// 第2天学习：暂时使用模拟数据，不请求后端
const useMockData = true;

const baseUrl = app.globalData.baseUrl || 'http://localhost:8080';

let loadingCount = 0;

const showLoading = () => {
  if (loadingCount === 0) {
    wx.showLoading({ title: '加载中...', mask: true });
  }
  loadingCount++;
};

const hideLoading = () => {
  if (loadingCount > 0) {
    loadingCount--;
  }
  if (loadingCount === 0) {
    wx.hideLoading();
  }
};

// 模拟数据
const mockData = {
  '/api/auth/login': {
    code: 200,
    message: 'success',
    data: {
      token: 'mock-token-12345',
      userId: 1,
      userNo: 's001',
      userName: '张三',
      role: 1,
      className: '计科2101班'
    }
  },
  '/api/student/active-tasks': {
    code: 200,
    message: 'success',
    data: []
  },
  '/api/student/records': {
    code: 200,
    message: 'success',
    data: [
      { id: 1, checkTime: Date.now() - 86400000, checkTypeText: '上课', status: 1 },
      { id: 2, checkTime: Date.now() - 172800000, checkTypeText: '下课', status: 2 },
      { id: 3, checkTime: Date.now() - 259200000, checkTypeText: '上课', status: 1 }
    ]
  }
};

const request = (url, method = 'GET', data = {}, needLoading = true) => {
  if (needLoading) {
    showLoading();
  }
  
  // 使用模拟数据
  if (useMockData) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (needLoading) hideLoading();
        const mock = mockData[url];
        if (mock) {
          resolve(mock.data);
        } else {
          resolve({});
        }
      }, 500);
    });
  }
  
  // 真实请求（后面阶段用）
  const token = wx.getStorageSync('token');
  const header = {
    'Content-Type': 'application/json'
  };
  if (token) {
    header['Authorization'] = 'Bearer ' + token;
  }
  return new Promise((resolve, reject) => {
    wx.request({
      url: baseUrl + url,
      method: method,
      data: data,
      header: header,
      success(res) {
        if (needLoading) hideLoading();
        if (res.statusCode === 401) {
          wx.removeStorageSync('token');
          wx.removeStorageSync('userInfo');
          wx.reLaunch({ url: '/pages/login/login' });
          reject(new Error('登录已过期'));
          return;
        }
        if (res.data.code === 200) {
          resolve(res.data.data);
        } else {
          wx.showToast({ title: res.data.message || '请求失败', icon: 'none' });
          reject(new Error(res.data.message || '请求失败'));
        }
      },
      fail(err) {
        if (needLoading) hideLoading();
        wx.showToast({ title: '网络异常，请检查网络', icon: 'none' });
        reject(err);
      }
    });
  });
};

const api = {
  // 认证
  login: (data) => request('/api/auth/login', 'POST', data),
  resetPassword: (data) => request('/api/auth/reset-password', 'POST', data),
  getUserInfo: () => request('/api/auth/user-info', 'GET'),

  // 学生端
  getActiveTasks: (classId) => request('/api/student/active-tasks?classId=' + (classId || ''), 'GET'),
  checkin: (data) => request('/api/student/checkin', 'POST', data),
  getRecords: () => request('/api/student/records', 'GET'),
  applyLeave: (classId, data) => request('/api/student/leave/apply?classId=' + classId, 'POST', data),
  getLeaveList: () => request('/api/student/leave/list', 'GET'),

  // 教师端
  createTask: (data) => request('/api/teacher/task/create', 'POST', data),
  getTeacherTasks: () => request('/api/teacher/task/list', 'GET'),
  getTaskDetail: (taskId) => request('/api/teacher/task/detail/' + taskId, 'GET'),
  deleteTask: (taskId) => request('/api/teacher/task/' + taskId, 'DELETE'),
  toggleFaceVerify: (taskId, needFace) => request('/api/teacher/task/' + taskId + '/face-verify/' + needFace, 'PUT'),
  exportTaskData: (taskId) => request('/api/teacher/task/export/' + taskId, 'GET'),
  getPendingLeaves: (classId) => request('/api/teacher/leave/pending/' + classId, 'GET'),
  getClassLeaves: (classId) => request('/api/teacher/leave/list/' + classId, 'GET'),
  approveLeave: (data) => request('/api/teacher/leave/approve', 'POST', data),

  // 管理员端
  getAllUsers: () => request('/api/admin/users', 'GET'),
  getUsersByRole: (role) => request('/api/admin/users/role/' + role, 'GET'),
  addUser: (data) => request('/api/admin/users', 'POST', data),
  updateUser: (data) => request('/api/admin/users', 'PUT', data),
  toggleUserStatus: (userId) => request('/api/admin/users/' + userId, 'PUT'),
  deleteUser: (userId) => request('/api/admin/users/' + userId, 'DELETE'),

  getAllClasses: () => request('/api/admin/classes', 'GET'),
  addClass: (data) => request('/api/admin/classes', 'POST', data),
  updateClass: (data) => request('/api/admin/classes', 'PUT', data),
  deleteClass: (classId) => request('/api/admin/classes/' + classId, 'DELETE'),

  getOverallStatistics: () => request('/api/admin/statistics/overall', 'GET'),
  getClassStatistics: () => request('/api/admin/statistics/classes', 'GET'),
  getAbnormalRecords: () => request('/api/admin/statistics/abnormal', 'GET'),
  getWeeklyTrend: () => request('/api/admin/statistics/weekly-trend', 'GET'),
};

module.exports = api;
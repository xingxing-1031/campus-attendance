const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');

Page({
  data: {
    classes: [],
    showForm: false,
    editMode: false,
    form: { id: null, className: '', grade: '', major: '', teacherId: null, semester: '' },
    submitting: false
  },

  onShow() {
    if (!auth.checkPermission()) return;
    this.loadData();
  },

  loadData() {
    api.getAllClasses().then(classes => {
      this.setData({ classes: classes || [] });
    });
  },

  onAddClass() {
    this.setData({
      showForm: true, editMode: false,
      form: { id: null, className: '', grade: '', major: '', teacherId: null, semester: '' }
    });
  },

  onEditClass(e) {
    const cls = e.currentTarget.dataset.class;
    this.setData({ showForm: true, editMode: true, form: { ...cls } });
  },

  onFormField(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ ['form.' + field]: e.detail.value });
  },

  onSubmit() {
    if (!this.data.form.className.trim()) {
      wx.showToast({ title: '请输入班级名称', icon: 'none' }); return;
    }
    this.setData({ submitting: true });
    const action = this.data.editMode ? api.updateClass(this.data.form) : api.addClass(this.data.form);
    action.then(() => {
      wx.showToast({ title: this.data.editMode ? '修改成功' : '添加成功', icon: 'success' });
      this.closeForm();
      this.loadData();
    }).finally(() => this.setData({ submitting: false }));
  },

  onDeleteClass(e) {
    const classId = e.currentTarget.dataset.classId;
    util.showConfirm('确认删除', '删除班级将影响班级关联数据，确定删除？').then(confirm => {
      if (confirm) {
        api.deleteClass(classId).then(() => {
          wx.showToast({ title: '已删除', icon: 'success' });
          this.loadData();
        });
      }
    });
  },

  closeForm() { this.setData({ showForm: false }); }
});
const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');
const app = getApp();

Page({
  data: {
    userInfo: null,
    users: [],
    classes: [],
    filterRole: 0,
    showForm: false,
    editMode: false,
    form: {
      id: null, userNo: '', password: '', name: '',
      role: 1, phone: '', email: '', classId: null, status: 1
    },
    submitting: false
  },

  onShow() {
    if (!auth.checkPermission()) return;
    this.setData({ userInfo: app.globalData.userInfo });
    this.loadData();
  },

  loadData() {
    const promise = this.data.filterRole > 0
      ? api.getUsersByRole(this.data.filterRole)
      : api.getAllUsers();
    Promise.all([promise, api.getAllClasses()]).then(([users, classes]) => {
      const formatted = (users || []).map(u => ({
        ...u,
        roleText: util.getRoleText(u.role),
        statusText: u.status === 1 ? '正常' : '禁用'
      }));
      this.setData({ users: formatted, classes: classes || [] });
    });
  },

  onFilterRole(e) {
    this.setData({ filterRole: parseInt(e.currentTarget.dataset.role) });
    this.loadData();
  },

  onAddUser() {
    this.setData({
      showForm: true, editMode: false,
      form: { id: null, userNo: '', password: '', name: '', role: 1, phone: '', email: '', classId: null, status: 1 }
    });
  },

  onEditUser(e) {
    const user = e.currentTarget.dataset.user;
    this.setData({
      showForm: true, editMode: true,
      form: {
        id: user.id, userNo: user.userNo, password: '', name: user.name,
        role: user.role, phone: user.phone || '', email: user.email || '',
        classId: user.classId, status: user.status
      }
    });
  },

  onFormField(e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    this.setData({ ['form.' + field]: field === 'role' || field === 'classId' || field === 'status' ? parseInt(value) || 0 : value });
  },

  onFormPickerClass(e) {
    const idx = e.detail.value;
    this.setData({ ['form.classId']: this.data.classes[idx].id });
  },

  onSubmit() {
    if (!this.data.form.userNo || !this.data.form.name) {
      wx.showToast({ title: '请填写必要信息', icon: 'none' }); return;
    }
    if (!this.data.editMode && !this.data.form.password) {
      wx.showToast({ title: '请输入密码', icon: 'none' }); return;
    }
    this.setData({ submitting: true });
    const action = this.data.editMode ? api.updateUser(this.data.form) : api.addUser(this.data.form);
    action.then(() => {
      wx.showToast({ title: this.data.editMode ? '修改成功' : '添加成功', icon: 'success' });
      this.closeForm();
      this.loadData();
    }).finally(() => this.setData({ submitting: false }));
  },

  onToggleStatus(e) {
    const userId = e.currentTarget.dataset.userId;
    api.toggleUserStatus(userId).then(() => {
      wx.showToast({ title: '状态已更新', icon: 'success' });
      this.loadData();
    });
  },

  onDeleteUser(e) {
    const userId = e.currentTarget.dataset.userId;
    util.showConfirm('确认删除', '确定要删除该用户吗？此操作不可恢复').then(confirm => {
      if (confirm) {
        api.deleteUser(userId).then(() => {
          wx.showToast({ title: '已删除', icon: 'success' });
          this.loadData();
        });
      }
    });
  },

  closeForm() {
    this.setData({ showForm: false });
  }
});
const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');
const app = getApp();

Page({
  data: {
    userInfo: null,
    tab: 'overview',
    overall: null,
    classStats: [],
    abnormalRecords: [],
    weeklyTrend: []
  },

  onShow() {
    if (!auth.checkPermission()) return;
    this.setData({ userInfo: app.globalData.userInfo });
    this.loadOverview();
  },

  loadOverview() {
    api.getOverallStatistics().then(res => {
      this.setData({ overall: res });
    });
  },

  loadClassStats() {
    api.getClassStatistics().then(res => {
      this.setData({ classStats: res || [] });
    });
  },

  loadAbnormal() {
    api.getAbnormalRecords().then(res => {
      this.setData({ abnormalRecords: res || [] });
    });
  },

  loadWeeklyTrend() {
    api.getWeeklyTrend().then(res => {
      this.setData({ weeklyTrend: res || [] });
    });
  },

  onSwitchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ tab });
    if (tab === 'overview') this.loadOverview();
    else if (tab === 'classes') this.loadClassStats();
    else if (tab === 'abnormal') this.loadAbnormal();
    else if (tab === 'trend') this.loadWeeklyTrend();
  },

  onToUsers() { wx.navigateTo({ url: '/pages/admin/users/users' }); },
  onToClasses() { wx.navigateTo({ url: '/pages/admin/classes/classes' }); },

  onLogout() { app.logout(); }
});
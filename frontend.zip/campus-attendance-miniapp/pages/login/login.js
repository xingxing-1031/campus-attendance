const api = require('../../utils/api');
const app = getApp();

Page({
  data: {
    userNo: '',
    password: '',
    loading: false
  },

  onLoad() {
    const token = wx.getStorageSync('token');
    if (token) {
      this.navigateByRole();
    }
  },

  onInputUserNo(e) {
    this.setData({ userNo: e.detail.value });
  },

  onInputPassword(e) {
    this.setData({ password: e.detail.value });
  },

  onLogin() {
    const { userNo, password } = this.data;
    if (!userNo.trim()) {
      wx.showToast({ title: '请输入学号/工号', icon: 'none' });
      return;
    }
    if (!password.trim()) {
      wx.showToast({ title: '请输入密码', icon: 'none' });
      return;
    }
    this.setData({ loading: true });
    api.login({ userNo: userNo.trim(), password: password }).then(res => {
      wx.setStorageSync('token', res.token);
      wx.setStorageSync('userInfo', res);
      app.globalData.token = res.token;
      app.globalData.userInfo = res;
      wx.showToast({ title: '登录成功', icon: 'success' });
      setTimeout(() => {
        this.navigateByRole();
      }, 800);
    }).catch(err => {
      console.error('登录失败:', err);
    }).finally(() => {
      this.setData({ loading: false });
    });
  },

  navigateByRole() {
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo) return;
    const role = userInfo.role;
    let url = '';
    switch (role) {
      case 1: url = '/pages/student/checkin/checkin'; break;
      case 2: url = '/pages/teacher/task/task'; break;
      case 3: url = '/pages/admin/statistics/statistics'; break;
      default: url = '/pages/login/login'; break;
    }
    wx.reLaunch({ url: url });
  }
});
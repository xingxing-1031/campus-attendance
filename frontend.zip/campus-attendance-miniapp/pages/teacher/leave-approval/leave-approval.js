const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');

Page({
  data: {
    classes: [],
    selectedClassId: null,
    selectedClassName: '',
    pendingLeaves: [],
    allLeaves: [],
    tab: 'pending',
    showApproveModal: false,
    currentLeave: null,
    approveStatus: 1,
    approveRemark: ''
  },

  onShow() {
    if (!auth.checkPermission()) return;
    this.loadClasses();
  },

  loadClasses() {
    api.getAllClasses().then(classes => {
      this.setData({ classes: classes || [] });
      if (classes && classes.length > 0 && !this.data.selectedClassId) {
        this.setData({
          selectedClassId: classes[0].id,
          selectedClassName: classes[0].className
        });
        this.loadLeaves();
      }
    });
  },

  onSelectClass(e) {
    const idx = e.detail.value;
    const cls = this.data.classes[idx];
    this.setData({
      selectedClassId: cls.id,
      selectedClassName: cls.className
    });
    this.loadLeaves();
  },

  loadLeaves() {
    if (!this.data.selectedClassId) return;
    Promise.all([
      api.getPendingLeaves(this.data.selectedClassId),
      api.getClassLeaves(this.data.selectedClassId)
    ]).then(([pending, all]) => {
      const formatLeaves = (leaves) => (leaves || []).map(l => ({
        ...l,
        leaveTypeText: util.getLeaveTypeText(l.leaveType),
        statusText: util.getLeaveStatusText(l.status),
        startTimeText: util.formatTime(l.startTime),
        endTimeText: util.formatTime(l.endTime),
        createTimeText: util.formatTime(l.createTime)
      }));
      this.setData({
        pendingLeaves: formatLeaves(pending),
        allLeaves: formatLeaves(all)
      });
    });
  },

  onSwitchTab(e) {
    this.setData({ tab: e.currentTarget.dataset.tab });
  },

  onApprove(e) {
    const leave = e.currentTarget.dataset.leave;
    this.setData({
      showApproveModal: true,
      currentLeave: leave,
      approveStatus: 1,
      approveRemark: ''
    });
  },

  onReject(e) {
    const leave = e.currentTarget.dataset.leave;
    this.setData({
      showApproveModal: true,
      currentLeave: leave,
      approveStatus: 2,
      approveRemark: ''
    });
  },

  onInputRemark(e) {
    this.setData({ approveRemark: e.detail.value });
  },

  onSubmitApprove() {
    const { currentLeave, approveStatus, approveRemark } = this.data;
    api.approveLeave({
      applicationId: currentLeave.id,
      status: approveStatus,
      remark: approveRemark
    }).then(() => {
      wx.showToast({ title: approveStatus === 1 ? '已批准' : '已驳回', icon: 'success' });
      this.closeApproveModal();
      this.loadLeaves();
    });
  },

  closeApproveModal() {
    this.setData({ showApproveModal: false, currentLeave: null });
  }
});
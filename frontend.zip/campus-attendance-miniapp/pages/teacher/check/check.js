const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');

Page({
  data: {
    taskId: null,
    task: null,
    records: [],
    checkedIn: 0,
    absent: 0,
    onLeave: 0
  },

  onLoad(options) {
    if (!auth.checkPermission()) return;
    this.setData({ taskId: options.taskId });
    this.loadDetail();
  },

  loadDetail() {
    api.getTaskDetail(this.data.taskId).then(res => {
      const records = (res.records || []).map(r => ({
        ...r,
        statusTag: r.status === 1 ? 'tag-success' : r.status === 2 ? 'tag-warning' : r.status === 4 ? 'tag-info' : 'tag-danger',
        checkTypeText: r.checkType ? (r.checkType === 1 ? 'GPS' : '扫码') : '-',
        faceText: r.faceVerified === 1 ? '通过' : r.faceVerified === 2 ? '失败' : '-'
      }));
      this.setData({
        task: res.task,
        records: records,
        checkedIn: res.checkedIn,
        absent: res.absent,
        onLeave: res.onLeave
      });
    });
  }
});
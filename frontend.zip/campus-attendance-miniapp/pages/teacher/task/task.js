const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');
const app = getApp();

Page({
  data: {
    userInfo: null,
    tasks: [],
    classes: [],
    showForm: false,
    title: '',
    classId: null,
    checkType: 1,
    locationName: '',
    latitude: '',
    longitude: '',
    locationRange: 500,
    needFace: 1,
    startTime: '',
    endTime: '',
    duration: 30,
    submitting: false,
    formErrors: {}
  },

  onShow() {
    if (!auth.checkPermission()) return;
    this.setData({ userInfo: app.globalData.userInfo });
    this.loadData();
  },

  loadData() {
    Promise.all([api.getTeacherTasks(), api.getAllClasses()]).then(([tasks, classes]) => {
      const formatted = (tasks || []).map(t => ({
        task: t.task,
        checkedIn: t.checkedIn,
        absent: t.absent,
        onLeave: t.onLeave,
        totalStudents: t.totalStudents,
        className: t.className
      }));
      this.setData({ tasks: formatted, classes: classes || [] });
    }).catch(err => console.error('加载数据失败:', err));
  },

  onShowForm() {
    const now = new Date();
    const endDate = new Date(now.getTime() + 30 * 60000);
    this.setData({
      showForm: true,
      startTime: util.formatTime(now),
      endTime: util.formatTime(endDate),
      formErrors: {}
    });
  },

  onHideForm() {
    this.setData({
      showForm: false, title: '', classId: null, checkType: 1,
      locationName: '', latitude: '', longitude: '', locationRange: 500,
      needFace: 1, duration: 30
    });
  },

  onInputTitle(e) { this.setData({ title: e.detail.value }); },
  onInputLocation(e) { this.setData({ locationName: e.detail.value }); },
  onInputLat(e) { this.setData({ latitude: e.detail.value }); },
  onInputLng(e) { this.setData({ longitude: e.detail.value }); },
  onInputRange(e) { this.setData({ locationRange: parseInt(e.detail.value) || 500 }); },
  onInputDuration(e) { this.setData({ duration: parseInt(e.detail.value) || 30 }); },

  onSelectClass(e) {
    const idx = e.detail.value;
    this.setData({ classId: this.data.classes[idx].id });
  },

  onSelectType(e) {
    this.setData({ checkType: parseInt(e.currentTarget.dataset.type) });
  },

  onToggleFace(e) {
    this.setData({ needFace: e.currentTarget.dataset.value });
  },

  onStartTimeChange(e) {
    const dateStr = e.detail.value;
    const now = new Date();
    const startDate = new Date(dateStr + ' ' + now.getHours() + ':' + now.getMinutes());
    const endDate = new Date(startDate.getTime() + this.data.duration * 60000);
    this.setData({
      startTime: util.formatTime(startDate),
      endTime: util.formatTime(endDate)
    });
  },

  onDurationChange(e) {
    const duration = parseInt(e.detail.value) || 30;
    if (this.data.startTime) {
      const startDate = new Date(this.data.startTime);
      const endDate = new Date(startDate.getTime() + duration * 60000);
      this.setData({ duration: duration, endTime: util.formatTime(endDate) });
    } else {
      this.setData({ duration: duration });
    }
  },

  onSubmit() {
    const errors = {};
    if (!this.data.title.trim()) errors.title = '请输入任务标题';
    if (!this.data.classId) errors.classId = '请选择班级';
    if (!this.data.startTime) errors.startTime = '请选择开始时间';
    if (this.data.checkType === 1 && !this.data.locationName.trim()) errors.locationName = 'GPS打卡需要填写地点名称';
    if (Object.keys(errors).length > 0) {
      this.setData({ formErrors: errors });
      return;
    }
    this.setData({ submitting: true, formErrors: {} });
    api.createTask({
      classId: this.data.classId,
      title: this.data.title.trim(),
      checkType: this.data.checkType,
      locationName: this.data.locationName,
      latitude: parseFloat(this.data.latitude) || 0,
      longitude: parseFloat(this.data.longitude) || 0,
      locationRange: this.data.locationRange,
      needFace: this.data.needFace,
      startTime: this.data.startTime,
      endTime: this.data.endTime
    }).then(res => {
      wx.showToast({ title: '创建成功', icon: 'success' });
      this.onHideForm();
      this.loadData();
    }).catch(err => {
      console.error('创建失败:', err);
    }).finally(() => {
      this.setData({ submitting: false });
    });
  },

  onViewDetail(e) {
    const taskId = e.currentTarget.dataset.taskId;
    wx.navigateTo({ url: '/pages/teacher/check/check?taskId=' + taskId });
  },

  onToggleFaceSwitch(e) {
    const { taskId, needFace } = e.currentTarget.dataset;
    const newNeedFace = needFace === 1 ? 0 : 1;
    api.toggleFaceVerify(taskId, newNeedFace).then(() => {
      wx.showToast({ title: '已切换', icon: 'success' });
      this.loadData();
    });
  },

  onExport(e) {
    const taskId = e.currentTarget.dataset.taskId;
    api.exportTaskData(taskId).then(data => {
      wx.setClipboardData({
        data: data,
        success() {
          wx.showToast({ title: '数据已复制到剪贴板', icon: 'success' });
        }
      });
    });
  },

  onDelete(e) {
    const taskId = e.currentTarget.dataset.taskId;
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个考勤任务吗？此操作不可撤销。',
      success: (res) => {
        if (res.confirm) {
          api.deleteTask(taskId).then(() => {
            wx.showToast({ title: '删除成功', icon: 'success' });
            this.loadData();
          });
        }
      }
    });
  },

  onToLeaveApproval() {
    wx.navigateTo({ url: '/pages/teacher/leave-approval/leave-approval' });
  },

  onLogout() {
    app.logout();
  }
});
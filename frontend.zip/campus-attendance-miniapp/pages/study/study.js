Page({
  onLoad(options) {
    console.log('页面加载了！', options);
  },
  onShow() {
    console.log('页面显示了！');
    console.log('当前的todos数据:', this.data.todos);
  },
  onReady() {
    console.log('页面渲染完成了！');
  },
  onHide() {
    console.log('页面隐藏了！');
  },
  onUnload() {
    console.log('页面卸载了！');
  },

  data: {
    count: 0,
    message: 'Hello World',
    fruits: ['苹果', '香蕉', '橙子'],
    extraCards: [],
    myName: '你的名字',
    isCheckedIn: false,
    students: [
      { id: 1, name: '小明', age: 18 },
      { id: 2, name: '小红', age: 17 },
      { id: 3, name: '小刚', age: 19 }
    ],
    checkinRecords: [
      {
        id: 1,
        title: '第6天学习签到',
        courseName: '微信小程序开发',
        checkinTime: '2026-05-29 09:30:00',
        location: '教学楼A101',
        isSuccess: true
      },
      {
        id: 2,
        title: '第5天学习签到',
        courseName: '微信小程序开发',
        checkinTime: '2026-05-28 10:15:00',
        location: '教学楼A101',
        isSuccess: false
      }
    ],
    todos: [
      { id: 1, title: '学习 wx:if', done: true },
      { id: 2, title: '学习 template', done: false },
      { id: 3, title: '学习 练习自己写代码', done: true }
    ]
  },

  addCount() {
    this.setData({
      count: this.data.count + 1
    });
  },

  minusCount() {
    this.setData({
      count: this.data.count - 1
    });
  },

  resetCount() {
    this.setData({
      count: 0
    });
  },

  changeMessage() {
    const messages = ['你好世界！', '学习 setData 真有趣！', '数据驱动视图！', '加油！'];
    const random = messages[Math.floor(Math.random() * messages.length)];
    this.setData({
      message: random
    });
  },

  addFruit() {
    const newFruits = ['葡萄', '草莓', '西瓜', '芒果'];
    const random = newFruits[Math.floor(Math.random() * newFruits.length)];
    const fruits = [...this.data.fruits, random];
    this.setData({
      fruits: fruits
    });
  },

  addCard() {
    const icons = ['📚', '📝', '📖', '🎓', '🏫', '✅', '❌', '⚠️'];
    const titles = ['请假申请', '成绩查询', '课程表', '作业提交', '通知公告', '资料下载'];
    const descs = ['待审批', '已通过', '进行中', '已完成', '新消息', '更新时间'];

    const randomIcon = icons[Math.floor(Math.random() * icons.length)];
    const randomTitle = titles[Math.floor(Math.random() * titles.length)];
    const randomDesc = descs[Math.floor(Math.random() * descs.length)];

    const newCard = {
      icon: randomIcon,
      title: randomTitle,
      desc: randomDesc
    };

    const cards = [...this.data.extraCards, newCard];
    this.setData({
      extraCards: cards
    });
  },

  changeName() {
    const names = ['张三', '李四', '王五', '赵六'];
    const randomIndex = Math.floor(Math.random() * names.length);
    this.setData({
      myName: names[randomIndex]
    });
  },

  toggleCheckin() {
    this.setData({
      isCheckedIn: !this.data.isCheckedIn
    });
  },

  onStudentClick(e) {
    const studentId = e.currentTarget.dataset.id;
    const studentName = e.currentTarget.dataset.name;
    
    wx.showToast({
      title: `${studentName}被点击了！`,
      icon: 'none'
    });
  },

  onCheckinCardClick(e) {
    const id = e.currentTarget.dataset.id;
    const title = e.currentTarget.dataset.title;
    
    wx.showToast({
      title: `${title}被点击了！`,
      icon: 'none'
    });
  },

  toggleTodo(e) {
    const id = e.currentTarget.dataset.id;
    console.log('点击的id:', id);
    console.log('更新前的todos:', this.data.todos);
    
    const todos = this.data.todos.map(
      todo => {
        if (todo.id === id) {
          return { ...todo, done: !todo.done }
        }
        return todo;
      }
    );
    
    console.log('更新后的todos:', todos);
    this.setData({ todos });
  },

  goToDetail() {
    console.log('goToDetail方法被调用了！');
    wx.navigateTo({
      url: '/pages/detail2/detail2?id=123&name=张三&course=微信小程序开发',
      success: function() {
        console.log('跳转成功！');
      },
      fail: function(err) {
        console.log('跳转失败！错误信息：', err);
      }
    });
  }
});

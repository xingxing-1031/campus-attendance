Page({
  data: {
    id: '',
    title: '',
    courseName: '',
    checkinTime: '',
    location: '',
    isSuccess: false
  },

  onLoad(options) {
    console.log('签到详情页加载了！参数是：', options);
    
    this.setData({
      id: options.id || '',
      title: decodeURIComponent(options.title || ''),
      courseName: decodeURIComponent(options.courseName || ''),
      checkinTime: decodeURIComponent(options.checkinTime || ''),
      location: decodeURIComponent(options.location || ''),
      isSuccess: options.isSuccess === 'true'
    });
  }
});

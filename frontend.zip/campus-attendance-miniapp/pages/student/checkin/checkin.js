const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');
const app = getApp();

Page({
  data: {
    myName: "张三",
    myAge: 22, 
    userInfo: null,
    tasks: [],
    showFaceModal: false,
    currentTask: null,
    faceImageBase64: '',
    checking: false
  },

  onShow() {
    console.log("签到页面显示了！");
    if (!auth.checkPermission()) return;
    this.setData({ userInfo: app.globalData.userInfo });
    this.loadTasks();
  },

  loadTasks() {
    const classId = this.data.userInfo ? this.data.userInfo.classId : null;
    api.getActiveTasks(classId).then(tasks => {
      this.setData({ tasks: tasks || [] });
    }).catch(err => console.error('加载任务失败:', err));
  },

  onGpsCheckin(e) {
    const task = e.currentTarget.dataset.task;
    if (task.needFace === 1) {
      this.setData({ showFaceModal: true, currentTask: task });
      return;
    }
    this.doGpsCheckin(task);
  },

  async doGpsCheckin(task) {
    this.setData({ checking: true });
    try {
      await auth.requestLocationPermission();
      const location = await auth.getLocation();
      const res = await api.checkin({
        taskId: task.taskId,
        checkType: 1,
        latitude: location.latitude,
        longitude: location.longitude,
        faceImageBase64: this.data.faceImageBase64 || ''
      });
      wx.showToast({ title: '打卡成功', icon: 'success' });
      this.closeFaceModal();
      this.loadTasks();
    } catch (err) {
      if (err.message && err.message.includes('活体检测未通过')) {
        wx.showModal({
          title: '验证失败',
          content: '活体检测未通过，请确保是本人实时拍摄，不要使用照片或视频',
          showCancel: false
        });
      } else if (err.message && err.message.includes('人脸验证未通过')) {
        wx.showModal({
          title: '验证失败',
          content: '人脸验证未通过，请重新拍摄',
          showCancel: false
        });
      } else if (err.message && err.message.includes('不在签到范围内')) {
        wx.showModal({
          title: '定位验证失败',
          content: err.message,
          showCancel: false
        });
      } else {
        wx.showToast({ title: err.message || '打卡失败', icon: 'none' });
      }
    } finally {
      this.setData({ checking: false });
    }
  },

  onQrCheckin(e) {
    const task = e.currentTarget.dataset.task;
    if (task.needFace === 1) {
      this.setData({ showFaceModal: true, currentTask: task });
      return;
    }
    this.doQrCheckin(task);
  },

  async doQrCheckin(task) {
    try {
      const qrResult = await auth.scanQrCode();
      const res = await api.checkin({
        taskId: task.taskId,
        checkType: 2,
        latitude: 0,
        longitude: 0,
        faceImageBase64: this.data.faceImageBase64 || ''
      });
      wx.showToast({ title: '扫码打卡成功', icon: 'success' });
      this.closeFaceModal();
      this.loadTasks();
    } catch (err) {
      if (err.errMsg && err.errMsg.includes('cancel')) return;
      wx.showToast({ title: err.message || '扫码打卡失败', icon: 'none' });
    }
  },

  onTakePhoto() {
    auth.chooseAndCompressImage().then(base64 => {
      this.setData({ faceImageBase64: base64 });
      const task = this.data.currentTask;
      if (task.checkType === 1 || task.checkType === 3) {
        this.doGpsCheckin(task);
      } else {
        this.doQrCheckin(task);
      }
    }).catch(err => {
      if (!err.message.includes('cancel')) {
        wx.showToast({ title: '拍照失败，请重试', icon: 'none' });
      }
    });
  },

  closeFaceModal() {
    this.setData({ showFaceModal: false, currentTask: null, faceImageBase64: '' });
  },

  onRefresh() {
    this.loadTasks();
  },

  onToRecords() {
    wx.navigateTo({ url: '/pages/student/records/records' });
  },

  onToLeave() {
    wx.navigateTo({ url: '/pages/student/leave/leave' });
  },

  onLogout() {
    app.logout();
  }
});
const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');

Page({
  data: {
    records: [],
    loading: true
  },

  onShow() {
    if (!auth.checkPermission()) return;
    this.loadRecords();
  },

  loadRecords() {
    this.setData({ loading: true });
    api.getRecords().then(records => {
      const formatted = (records || []).map(r => ({
        id: r.id,
        title: `${r.checkTypeText}签到`,
        courseName: '日常考勤',
        checkinTime: util.formatTime(r.checkTime),
        location: '教学楼',
        isSuccess: r.status === 1
      }));
      this.setData({ records: formatted, loading: false });
    }).catch(err => {
      console.error('加载记录失败:', err);
      this.setData({ loading: false });
    });
  },

  onRecordClick(e) {
    const id = e.currentTarget.dataset.id;
    const record = this.data.records.find(r => r.id === id);
    
    const url = `/pages/detail2/detail2?id=${record.id}&title=${encodeURIComponent(record.title)}&courseName=${encodeURIComponent(record.courseName)}&checkinTime=${encodeURIComponent(record.checkinTime)}&location=${encodeURIComponent(record.location)}&isSuccess=${record.isSuccess}`;
    
    wx.navigateTo({ url });
  }
});

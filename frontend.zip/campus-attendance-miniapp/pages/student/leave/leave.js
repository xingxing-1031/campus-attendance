const api = require('../../../utils/api');
const util = require('../../../utils/util');
const auth = require('../../../utils/auth');
const app = getApp();

Page({
  data: {
    userInfo: null,
    leaves: [],
    showForm: false,
    leaveType: 1,
    reason: '',
    startTime: '',
    endTime: '',
    taskId: null,
    submitting: false
  },

  onShow() {
    if (!auth.checkPermission()) return;
    this.setData({ userInfo: app.globalData.userInfo });
    this.loadLeaves();
  },

  loadLeaves() {
    api.getLeaveList().then(leaves => {
      const formatted = (leaves || []).map(l => ({
        ...l,
        leaveTypeText: util.getLeaveTypeText(l.leaveType),
        statusText: util.getLeaveStatusText(l.status),
        startTimeText: util.formatTime(l.startTime),
        endTimeText: util.formatTime(l.endTime),
        approveTimeText: util.formatTime(l.approveTime)
      }));
      this.setData({ leaves: formatted });
    }).catch(err => console.error('加载请假列表失败:', err));
  },

  onShowForm() {
    this.setData({ showForm: true });
  },

  onHideForm() {
    this.setData({ showForm: false, leaveType: 1, reason: '', startTime: '', endTime: '' });
  },

  onSelectType(e) {
    this.setData({ leaveType: parseInt(e.currentTarget.dataset.type) });
  },

  onInputReason(e) {
    this.setData({ reason: e.detail.value });
  },

  onStartTimeChange(e) {
    this.setData({ startTime: e.detail.value });
  },

  onEndTimeChange(e) {
    this.setData({ endTime: e.detail.value });
  },

  onSubmit() {
    const { leaveType, reason, startTime, endTime, userInfo } = this.data;
    if (!reason.trim()) {
      wx.showToast({ title: '请填写请假原因', icon: 'none' });
      return;
    }
    if (!startTime || !endTime) {
      wx.showToast({ title: '请选择请假时间', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });
    api.applyLeave(userInfo.classId, {
      leaveType: leaveType,
      reason: reason.trim(),
      startTime: startTime + ':00',
      endTime: endTime + ':00'
    }).then(res => {
      wx.showToast({ title: '提交成功', icon: 'success' });
      this.onHideForm();
      this.loadLeaves();
    }).catch(err => {
      console.error('提交失败:', err);
    }).finally(() => {
      this.setData({ submitting: false });
    });
  }
});